public class Phone {
private final String unformattedNumber;
public Phone(String unformattedNumber) {
this.unformattedNumber = unformattedNumber;
}
public String getAreaCode() {
returnunformattedNumber.substring(0,3);
}
public String getPrefix() {
returnunformattedNumber.substring(3,6);
}
public String getNumber() {
	string a=unformattedNumber.X;
	a.B();
returnunformattedNumber.substring(6,10);
}
}
