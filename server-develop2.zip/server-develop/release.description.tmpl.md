 [Release notes](CHANGELOG.md#MmP)
 Binary distributions available on [Maven Central Repository](http://repo1.maven.org/maven2/org/ow2/authzforce/authzforce-ce-server-dist/M.m.P/) in two forms:
 * Ubuntu package (recommended option): `.deb`;
 * Other Linux distributions: `.tar.gz`.

 Docker image available on [Docker Hub](https://hub.docker.com/r/fiware/authzforce-ce-server/tags/).

 Documentation available [online](http://authzforce-ce-fiware.readthedocs.io/en/release-M.m.P/) and as downloadable [HTML](https://media.readthedocs.org/htmlzip/authzforce-ce-fiware/release-M.m.P/authzforce-ce-fiware.zip) and [PDF](https://media.readthedocs.org/pdf/authzforce-ce-fiware/release-M.m.P/authzforce-ce-fiware.pdf).
